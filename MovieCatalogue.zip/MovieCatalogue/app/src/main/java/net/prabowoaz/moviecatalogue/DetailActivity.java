package net.prabowoaz.moviecatalogue;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    TextView titleFilm, descFilm;
    ImageView gambar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        titleFilm = findViewById(R.id.judulFilm);
        descFilm = findViewById(R.id.filmDesc);
        gambar = findViewById(R.id.gambarFilm);

        Film film = getIntent().getParcelableExtra("EXTRA_FILM");
        String judulFilm = film.getJudul();
        getSupportActionBar().setTitle(judulFilm);

        titleFilm.setText(film.getJudul());
        descFilm.setText(film.getRingkasan());
        gambar.setImageResource(film.getFoto());
    }
}
