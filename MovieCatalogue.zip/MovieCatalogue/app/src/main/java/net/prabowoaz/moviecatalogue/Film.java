package net.prabowoaz.moviecatalogue;

import android.os.Parcel;
import android.os.Parcelable;

public class Film implements Parcelable {
    private int foto;
    private String judul;
    private String ringkasan;
    private String tanggal;
    private String rating;
    private String durasi;
    private String anggaran;
    private String pemasukkan;

    public Film() {
    }

    protected Film(Parcel in) {
        foto = in.readInt();
        judul = in.readString();
        ringkasan = in.readString();
        tanggal = in.readString();
        rating = in.readString();
        durasi = in.readString();
        anggaran = in.readString();
        pemasukkan = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(foto);
        dest.writeString(judul);
        dest.writeString(ringkasan);
        dest.writeString(tanggal);
        dest.writeString(rating);
        dest.writeString(durasi);
        dest.writeString(anggaran);
        dest.writeString(pemasukkan);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Film> CREATOR = new Creator<Film>() {
        @Override
        public Film createFromParcel(Parcel in) {
            return new Film(in);
        }

        @Override
        public Film[] newArray(int size) {
            return new Film[size];
        }
    };

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public String getRingkasan() {
        return ringkasan;
    }

    public void setRingkasan(String ringkasan) {
        this.ringkasan = ringkasan;
    }

    public String getTanggal() {
        return tanggal;
    }

    public void setTanggal(String tanggal) {
        this.tanggal = tanggal;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getDurasi() {
        return durasi;
    }

    public void setDurasi(String durasi) {
        this.durasi = durasi;
    }

    public String getAnggaran() {
        return anggaran;
    }

    public void setAnggaran(String anggaran) {
        this.anggaran = anggaran;
    }

    public String getPemasukkan() {
        return pemasukkan;
    }

    public void setPemasukkan(String pemasukkan) {
        this.pemasukkan = pemasukkan;
    }
}
